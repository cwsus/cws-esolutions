#include <stdio.h>

main(int argc, char* argv[])
{
    if (argc == 1)
    {
        printf("No arguments were provided. Unable to provide requested information.\n");

        return 1;
    }
    else
    {
        printf("No configuration has been performed. Please modify the source, provide information, and re-compile.");
    }
}

