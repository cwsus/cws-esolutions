#MUST HAVE APR AND APR-UTIL -
#    this REQUIRES openldap-devel
#    for apr:./configure --enable-threads --enable-other-child && make && make install
#        this will install to /usr/local/apr/
#    for apr-util: ./configure --with-apr=/usr/local/apr --with-ldap-lib=/usr/lib --with-ldap-include=/usr/include --with-ldap=ldap && make && make install
#        this will install to /usr/local/apr
#    for apr-iconv: ./configure --with-apr=/usr/local/apr --with-ldap-lib=/usr/lib --with-ldap-include=/usr/include --with-ldap=ldap && make && make install
#        this will install to /usr/local/apache2/lib/iconv

export CFLAGS="-m64";
export CXXFLAGS="-m64";
export LD_FLAGS="-m64";

APR_LOCATION=/home/khuntly/Downloads/apr-1.4.6
APR_UTIL_LOCATION=/home/khuntly/Downloads/apr-util-1.5.1
APR_ICONV_LOCATION=/home/khuntly/Downloads/apr-iconv-1.2.1

if [ ! -z ${APR_LOCATION} ]
then
    cd ${APR_LOCATION};
    ./configure --enable-threads --enable-other-child && make && make install
fi

if [ ! -z ${APR_UTIL_LOCATION} ]
then
    cd ${APR_UTIL_LOCATION};
    ./configure --with-apr=/usr/local/apr --with-ldap-lib=/usr/lib --with-ldap-include=/usr/include --with-ldap=ldap && make && make install
fi

if [ ! -z ${APR_ICONV_LOCATION} ]
then
    cd ${APR_ICONV_LOCATION};
    ./configure --with-apr=/usr/local/apr --with-ldap-lib=/usr/lib --with-ldap-include=/usr/include --with-ldap=ldap && make && make install
fi

HTTPD_VERSION=2.4.3
HTTPD_LOCATION=/home/khuntly/Downloads/httpd-2.4.3
HTTPD_OWNER=webadm
HTTPD_USER=webusr
HTTPD_GROUP=webgrp

cd ${HTTPD_LOCATION};
./configure --prefix=/opt/Apache/httpd/${HTTPD_VERSION} \
    --with-ldap-lib=/usr/lib \
    --with-ldap-include=/usr/include \
    --with-ldap=ldap \
    --with-ssl=/usr/bin \
    --with-apr=/usr/local/apr \
    --with-apr-util=/usr/local/apr \
    --mandir=/usr/share/man \
    --enable-auth-basic=shared \
    --enable-auth-digest=shared \
    --enable-charset-lite=shared \
    --enable-rewrite=shared \
    --enable-alias=shared \
    --enable-headers=shared \
    --enable-log-config=shared \
    --enable-proxy=shared \
    --enable-proxy-http=shared \
    --enable-proxy-ftp=shared \
    --enable-proxy-connect=shared \
    --enable-proxy-ajp=shared \
    --enable-mime=shared \
    --enable-mime-magic=shared \
    --enable-ssl=shared \
    --enable-expires=shared \
    --enable-deflate=shared \
    --enable-cache=shared \
    --enable-file-cache=shared \
    --enable-disk-cache=shared \
    --enable-mem-cache=shared \
    --enable-usertrack=shared \
    --enable-alias=shared \
    --enable-dir=shared \
    --enable-setenvif=shared \
    --enable-userdir=shared \
    --enable-access=shared \
    --enable-ldap=shared \
    --enable-auth-ldap=shared \
    --enable-authnz-ldap=shared \
    --disable-actions \
    --disable-asis \
    --disable-autoindex \
    --disable-cgi \
    --disable-cgid \
    --disable-include \
    --disable-status \
    --disable-dav \
    --disable-dav-fs \
    --disable-ext-filter \
    --disable-info \
    --disable-isapi && make && make install;

if [ $(grep -c ${HTTPD_GROUP} /etc/group) != 1 ]
then
    groupadd -r ${HTTPD_GROUP};
fi

for ACCOUNT in ${HTTPD_OWNER} ${HTTPD_USER}
do
    if [ $(grep -c ${ACCOUNT} /etc/passwd) != 1 ]
    then
        if [ "${ACCOUNT}" == "${HTTPD_USER}" ]
        then
            useradd -b /opt/home/${ACCOUNT} -d /opt/home/${ACCOUNT} -g webgrp -M -N -r -s /sbin/nologin ${ACCOUNT};
        else
            useradd -b /opt/home/${ACCOUNT} -d /opt/home/${ACCOUNT} -g webgrp -M -N -r -s /bin/bash ${ACCOUNT};
        fi
    fi
done

## make directories
mkdir -p /var/srv/httpd /var/cache/httpd /var/log/httpd /var/run/httpd;

## copy apachectl
[ -d /opt/home ] && mkdir -p /opt/home;
mkdir -p /opt/home/${HTTPD_USER}/bin;
cp /opt/Apache/httpd/${HTTPD_VERSION}/bin/apachectl /opt/home/${HTTPD_USER}/bin/apachectl;
chown -R -h ${HTTPD_USER}. /opt/home/${HTTPD_USER};

## change install ownership
cd /opt/Apache;
ln -s /opt/Apache/httpd/${HTTPD_VERSION} /opt/Apache/httpd/current;
chown -R -h ${HTTPD_OWNER}:${HTTPD_GROUP} /opt/Apache/httpd /opt/Apache/httpd;
chown -R -h ${HTTPD_USER}:${HTTPD_GROUP} /var/srv/httpd /var/cache/httpd /var/log/httpd /var/run/httpd;

