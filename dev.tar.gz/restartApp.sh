#!/usr/bin/env ksh
#==============================================================================
#
#          FILE:  executeServiceRestart.sh
#         USAGE:  ./executeServiceRestart.sh instance command
#   DESCRIPTION:  Connects to the provided DNS server and restarts the named
#                 process. Utilized to apply pending changes, or to recycle
#                 the service if required for any other reason.
#
#       OPTIONS:  ---
#  REQUIREMENTS:  ---
#          BUGS:  ---
#         NOTES:  ---
#        AUTHOR:  $Author: kmhuntly $
#       COMPANY:  CaspersBox Web Services
#       VERSION:  $Revision: 1714 $
#       CREATED:  $Date: 2011-11-17 16:20:20 -0500 (Thu, 17 Nov 2011) $
#      REVISION:  ---
#==============================================================================

WAS_INSTALL_ROOT=/opt/WebSphere61/AppServer
WAS_PROFILE_NAME=appprofile
WAS_STOP_MSG=ADMU4000I
WAS_START_MSG=ADMU3000I

STOP_SERVER_CMD=stopServer.sh
START_SERVER_CMD=startServer.sh
SERVER_STAT_CMD=serverStatus.sh

#===  FUNCTION  ===============================================================
#          NAME:  serviceControl
#   DESCRIPTION:  Processes and implements a DNS site failover
#    PARAMETERS:  Parameters obtained via command-line flags
#       RETURNS:  0 for positive result, >1 for non-positive
#==============================================================================
stopServer()
{
    ## capture server name
    SERVER_NAME=${1};
    SERVER_LOG_PATH=${2};

    ## make sure its not empty..
    if [ ! -z ${SERVER_NAME} ]
    then
        PID_FILE_NAME=${WAS_INSTALL_ROOT}/profiles/${WAS_PROFILE_NAME}/logs/${SERVER_NAME}/${SERVER_NAME}.pid;

        ## make sure it actually exists and is started
        STATUS_TXT=${WAS_INSTALL_ROOT}/profiles/${WAS_PROFILE_NAME}/bin/${SERVER_STAT_CMD} ${SERVER_NAME} | grep ${WAS_START_MSG};

        if [ ! -z ${STATUS_TXT} ] && [ "${STATUS_TXT}" != "" ]
        then
            ## server exists and is running, shut it down
            exec ${WAS_INSTALL_ROOT}/profiles/${WAS_PROFILE_NAME}/bin/${STOP_SERVER_CMD} ${SERVER_NAME} 2>&1 & PIDID=$!;
            wait ${PIDID};

            ## verify process
            verifyProcess start;
        else
            ## couldnt determine current server status with built-in commands
            ## try and stop it and see what shakes loose
            exec ${WAS_INSTALL_ROOT}/profiles/${WAS_PROFILE_NAME}/bin/${STOP_SERVER_CMD} ${SERVER_NAME} 2>&1 & PIDID=$!;
            wait ${PIDID};

            ## verify process
            verifyProcess start;
        fi
    else
        ## no server name was provided
    fi
}

#===  FUNCTION  ===============================================================
#          NAME:  serviceControl
#   DESCRIPTION:  Processes and implements a DNS site failover
#    PARAMETERS:  Parameters obtained via command-line flags
#       RETURNS:  0 for positive result, >1 for non-positive
#==============================================================================
stopServer()
{
    ## capture server name
    SERVER_NAME=${1};

    ## make sure its not empty..
    if [ ! -z ${SERVER_NAME} ]
    then
        PID_FILE_NAME=${WAS_INSTALL_ROOT}/profiles/${WAS_PROFILE_NAME}/logs/${SERVER_NAME}/${SERVER_NAME}.pid;

        ## make sure it actually exists and is started
        STATUS_TXT=${WAS_INSTALL_ROOT}/profiles/${WAS_PROFILE_NAME}/bin/${SERVER_STAT_CMD} ${SERVER_NAME} | grep ${WAS_STOP_MSG};

        if [ ! -z ${STATUS_TXT} ] && [ "${STATUS_TXT}" != "" ]
        then
            ## server exists and is stopped, start it up
            exec ${WAS_INSTALL_ROOT}/profiles/${WAS_PROFILE_NAME}/bin/${START_SERVER_CMD} ${SERVER_NAME} 2>&1 & PIDID=$!;
            wait ${PIDID};

            ## verify process
            verifyProcess stop;
        else
            ## couldnt determine current server status with built-in commands
            ## try and stop it and see what shakes loose
            exec ${WAS_INSTALL_ROOT}/profiles/${WAS_PROFILE_NAME}/bin/${START_SERVER_CMD} ${SERVER_NAME} 2>&1 & PIDID=$!;
            wait ${PIDID};

            ## verify process
            verifyProcess stop;
        fi
    else
        ## no server name was provided
    fi
}

#===  FUNCTION  ===============================================================
#          NAME:  serviceControl
#   DESCRIPTION:  Processes and implements a DNS site failover
#    PARAMETERS:  Parameters obtained via command-line flags
#       RETURNS:  0 for positive result, >1 for non-positive
#==============================================================================
verifyProcess()
{
    PROCESS_STATUS=${1};

    if [ ! -z ${PROCESS_STATUS} ]
    then
        case ${PROCESS_STATUS} in
            start)
                ## check to see if it started - since the exec doesnt capture the return code from the existing script (and it doesnt matter
                ## anyway) check sysout, verify theres a pid, etc etc
                if [ -s ${PID_FILE_NAME} ]
                then
                    ## pid exists, see if the pid is running
                    PROCESS_OUTPUT=$(ps | grep ${SERVICE_PID} | grep -v grep | grep -v ${CNAME});

                    if [ ! -z ${PROCESS_OUTPUT} ] && [ "${PROCESS_OUTPUT}" != "" ]
                    then
                        ## server startup should be complete, check syslog
                        IS_RUNNING=$(tail -30 ${SERVER_LOG_PATH}/SystemOut.log | grep "open for e-business");

                        if [ ! -z ${IS_RUNNING} ]
                        then
                            ## server running, notify
                            exit 0;
                        else
                            ## startup failed, notify
                            exit 1;
                        fi
                    else
                        ## server started
                        exit 0;
                    fi
                else
                    ## server startup failed
                    exit 1;
                fi
                ;;
            stop)
                ## check to see if it started - since the exec doesnt capture the return code from the existing script (and it doesnt matter
                ## anyway) check sysout, verify theres a pid, etc etc
                if [ -s ${PID_FILE_NAME} ]
                then
                    ## pid exists, see if the pid is running
                    PROCESS_OUTPUT=$(ps | grep ${SERVICE_PID} | grep -v grep | grep -v ${CNAME});

                    if [ -z ${PROCESS_OUTPUT} ] && [ "${PROCESS_OUTPUT}" == "" ]
                    then
                        ## server stopped
                        exit 0;
                    else
                        ## server stopped
                        exit 1;
                    fi
                else
                    ## server stopped
                    exit 0;
                fi
                ;;
            *)
        esac
    else
        ## no modifier provided
    fi
}

#===  FUNCTION  ===============================================================
#          NAME:  usage
#   DESCRIPTION:  Processes and implements a DNS site failover
#    PARAMETERS:  Parameters obtained via command-line flags
#       RETURNS:  0 for positive result, >1 for non-positive
#==============================================================================
usage()
{
    METHOD_NAME="serverControl#usage()";

    print "$0 - stop, start, or restart a selected service.";
    print "Usage: $0 <instance> <control command>";
    print " No arguments are required to operate this utility.";
    print " -h|-? -> Show this help";

    RETURN_CODE=3;
}

if [ $# != 2 ]
then
    usage;
else
    COMMAND=$(echo ${2} | tr '[A-Z]' '[a-z]';

    case ${COMMAND} in
        start)
            startServer ${@};
            ;;
        stop)
            stopServer ${@};
            ;;
        *)
            usage;
            ;;
    esac
fi
